//
//  InfoView.swift
//  Prophecy
//
//  Created by Ana Flávia Torres do Carmo on 16/12/24.
//

import SwiftUI

struct InfoView: View {
    @EnvironmentObject var router: Router
    @State private var screenWidth = UIScreen.main.bounds.width
    @State private var screenHeight = UIScreen.main.bounds.height
    
    var body: some View {
            VStack {
                VStack(alignment: .leading) {
                    Text("Prophecy")
                        .font(.system(size: 41, weight: .medium))
                        .padding(.bottom)
                    
                    Text("In this Playground, you will have the opportunity to explore one of the Bible’s most enigmatic prophecies in an interactive and fun way: the vision of the statue described in the book of Daniel, chapter 2. Through a simple and engaging experience, you will learn about the different kingdoms represented by the statue and discover the deep meaning behind this prophecy that transcends time. Get ready to explore, learn, and perhaps see these truths from a new perspective!")
                        .padding(.bottom, 60)
//                    Button(action: {router.goToIntroView()}) {
                        HStack {
                            Text("1. A Scary Statue")
                                .padding(.leading)
                            Divider()
                                .frame(width: screenWidth/1.6, height: 1)
                                .background(Color.text)
                                .accessibilityHidden(true)
                        }
//                    }
////                    .foregroundStyle(Color.background)
//                    .frame(maxWidth: .infinity, alignment: .leading)
//                    .frame(height: 60)
////                    .background(Color.text)
//                    .clipShape(RoundedRectangle(cornerRadius: 10))

                }
                .padding(.vertical, 20)
                
                Spacer()
                // Next Button
                HStack {
                    Spacer()
                    withAnimation(.easeInOut) {
                        Button(action: {router.goToIntroView()}) {
                            Image(systemName: "play.circle.fill")
                                .font(.system(size: 60))
                        }
                        .accessibilityLabel("Start")
                    }
                }
            }
            .padding(.horizontal,50)
            .background(Color.background)
            .toolbar(.hidden, for: .navigationBar)
            .foregroundStyle(Color.text)
            .font(.system(size: 25, weight: .medium))
    }
}

#Preview {
    InfoView()
        .environmentObject(Router())
}
