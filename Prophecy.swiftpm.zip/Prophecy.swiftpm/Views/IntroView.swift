//
//  SwiftUIView.swift
//  Prophecy
//
//  Created by Ana Flávia Torres do Carmo on 05/12/24.
//

import SwiftUI

struct IntroView: View {
    @EnvironmentObject var router: Router
    
    var body: some View {
            VStack {
                VStack(alignment: .leading) {
                    Text("Introduction")
                        .font(.system(size: 41, weight: .medium))
                    Text("Dn 2:1-30")
                        .font(.system(size: 28, weight: .medium))
                        .padding(.bottom)
                    
                    Text("“In the second year of Nebuchadnezzar as king of Babylon, he had a dream that troubled him so much that he could not sleep.” Dan 2:1 (NLT) “So he summoned the wise men… to interpret the dream.” Dan 2:2 (NLT) “…If you cannot do this, you will all be cut into pieces, and your houses will be completely destroyed.” Dan 2:5 (NLT)")
                }
                .padding(.vertical, 20)
                
                // Nabuco images
                HStack {
                    Spacer()
                    // TODO: dream ballon
                    Image("nabuco_s")
                        .resizable()
                        .scaledToFit()
                        .accessibilityLabel("Image of Nebuchadnezzar dreaming")
                    Spacer()
                    Image("nabuco_i")
                        .resizable()
                        .scaledToFit()
                        .accessibilityLabel("Image of Nebuchadnezzar troubled")
                    Spacer()
                }
                
                VStack(alignment: .leading) {
                    Text("“Daniel asked them to pray to the God of heaven, pleading for mercy and for Him to reveal the meaning of the mysterious dream, so that Daniel and his friends would not perish along with the other wise men of Babylon. That night, Daniel had a vision in which God revealed the meaning of the dream ...” Dan 2:18,19 (NLT)")
                }
                .padding(.vertical, 20)
                
                // Daniel images
                HStack {
                    Spacer()
                    Image("daniel_o")
                        .resizable()
                        .scaledToFit()
                        .accessibilityLabel("Image of Daniel praying")
                    Spacer()
                    // TODO: ligth
                    Image("daniel")
                        .resizable()
                        .scaledToFit()
                        .accessibilityLabel("Image of Daniel having the revelation")
                    Spacer()
                }// Next Button
                HStack {
                    Spacer()
                    withAnimation(.easeInOut) {
                        Button(action: {router.goToDreamView()}) {
                            Image(systemName: "arrowshape.turn.up.right.circle.fill")
                                .font(.system(size: 60))
                        }
                        .accessibilityLabel("Next")
                    }
                }
                Spacer()
            }
            .padding(.horizontal,50)
            .background(Color.background)
            .toolbar(.hidden, for: .navigationBar)
            .foregroundStyle(Color.text)
            .font(.system(size: 25, weight: .medium))
    }
}

#Preview {
    IntroView()
        .environmentObject(Router())
}
