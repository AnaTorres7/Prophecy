//
//  SwiftUIView.swift
//  Prophecy
//
//  Created by Ana Flávia Torres do Carmo on 03/12/24.
//

import SwiftUI

struct CoverView: View {
    @EnvironmentObject var router: Router
    let screenWidth = UIScreen.main.bounds.width
    let screenHeight = UIScreen.main.bounds.height
    @State var showModal: Bool = false
    
    var body: some View {
        NavigationStack(path: $router.path) {
            ZStack {
                // background
                Rectangle()
                    .fill(RadialGradient(gradient: Gradient(colors: [Color(red: 0.58, green: 0.35, blue: 0.19),Color(red: 0.43, green: 0.22, blue: 0.11)]), center: .center, startRadius: 150, endRadius: 400))
                    .ignoresSafeArea()
                // stroke
                Rectangle()
                    .stroke(Color(red: 0.96, green: 0.85, blue: 0.72), lineWidth: 5)
                    .padding(30)
                Image("Prophecy")
                    .resizable()
                    .scaledToFit()
                    .padding(200)
                    .accessibilityLabel("Prophecy")
                VStack {
                    Spacer()
                    Image(decorative: "mini_cross")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 70)
                        .padding(70)
                }
                // ribbon - open button
                VStack {
                    HStack {
                        Button(action: { router.goToInfoView() }) {
                            Image(decorative: "ribbon")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 200)
                                .padding(.leading, 60)
                        }
                        Spacer()
                    }
                    Spacer()
                }
                .ignoresSafeArea()
                
                if showModal {
                    // Fundo semitransparente
                    Color.black.opacity(0.5)
                        .edgesIgnoringSafeArea(.all)
                        .overlay(
                            VStack {
                                Text("In this Playground, you will have the opportunity to explore one of the Bible’s most enigmatic prophecies in an interactive and fun way: the vision of the statue described in the book of Daniel, chapter 2. Through a simple and engaging experience, you will learn about the different kingdoms represented by the statue and discover the deep meaning behind this prophecy that transcends time. Get ready to explore, learn, and perhaps see these truths from a new perspective!")
                                    .padding()
                                    .multilineTextAlignment(.center)
                                
                                Divider()
                                    .background(Color.gray)
                                
                                Button("Let's Go") {
                                    withAnimation(.easeInOut) {
                                        showModal = false
                                    }
                                }
                                .padding()
                                .fontWeight(.semibold)
                                .foregroundStyle(Color.text)
                                .cornerRadius(10)
                            }
                                .background(Color.background)
                                .cornerRadius(15)
                                .shadow(radius: 20)
                                .padding(100)
                        )
                }
            }
            .toolbar(.hidden, for: .navigationBar)
            .navigationDestination(for: NavigationDestinations.self) { destination in
                getView(destination)
            }
            .foregroundStyle(Color.text)
            .font(.system(size: 25, weight: .regular))
//            .onAppear {
//                Task {
//                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
//                        showModal = true
//                    }
//                }
//            }
        }
        .environmentObject(router)
    }
}

#Preview {
    CoverView()
}
