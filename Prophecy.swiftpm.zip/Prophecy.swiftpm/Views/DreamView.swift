//
//  SwiftUIView.swift
//  Prophecy
//
//  Created by Ana Flávia Torres do Carmo on 08/12/24.
//

import SwiftUI

struct DreamView: View {
    @EnvironmentObject var router: Router
    @StateObject private var viewModel = DreamViewModel()
    @State var showInterpretation: Bool = false
    @State var showInstruction: Bool = false
    @State var showX: Bool = false
    
    var body: some View {
            VStack {
                VStack(alignment: .leading) {
                    Text(viewModel.getPartName())
                        .font(.system(size: 41, weight: .medium))
                    Text(viewModel.currentPart.referenceText)
                        .font(.system(size: 28, weight: .medium))
                        .padding(.bottom)
                    Text(viewModel.currentPart.verseText)
                        .font(.system(size: 25, weight: .medium))
                }
                .padding(.vertical, 20)
                .frame(maxWidth: .infinity, alignment: .leading)
                
                VStack {
                    Spacer()
                    
                    if viewModel.isResponseCorrect {
                        Image(viewModel.currentPart.statueImage)
                            .resizable()
                            .scaledToFit()
                            .frame(maxWidth: 500)
                            .padding()
                            .accessibilityLabel("Image of \(viewModel.getPartName()) of \(viewModel.currentPart.materialImage)")
                    } else {
                        if viewModel.currentPart.name == "Feet" && viewModel.response == ["Clay"]{
                            Image("Feet_C")
                                .resizable()
                                .scaledToFit()
                                .frame(maxWidth: 500)
                                .padding()
                                .accessibilityLabel("Image of \(viewModel.getPartName()) of clay")
                        } else if viewModel.currentPart.name == "Feet" && viewModel.response == ["Iron"] {
                            Image("Feet_I")
                                .resizable()
                                .scaledToFit()
                                .frame(maxWidth: 500)
                                .padding()
                                .accessibilityLabel("Image of \(viewModel.getPartName()) of iron")
                        } else {
                            Image(viewModel.currentPart.name)
                                .resizable()
                                .scaledToFit()
                                .frame(maxWidth: 500)
                                .padding()
                                .accessibilityLabel("Black and white image of \(viewModel.getPartName())")
                        }
                    }
                    
                    Spacer()
                    
                    HStack {
                        Spacer()
                        ForEach(Materials.allCases, id: \.self) { material in
                            VStack {
                                Image(decorative: "\(material)")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(maxWidth: 110)
                                Text("\(material)")
                                    .font(.system(size: 25, weight: .medium))
                            }
                            .onTapGesture {
                                if viewModel.currentPart.materialImage.contains("\(material)") && !viewModel.response.contains("\(material)") {
                                    viewModel.response.append("\(material)")
                                    if Set(viewModel.response) == Set(viewModel.currentPart.materialImage) {
                                        viewModel.isResponseCorrect.toggle()
                                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                                            showInterpretation.toggle()
                                        }
                                    }
                                } else {
                                    withAnimation(.easeInOut) {
                                        showX.toggle()
                                    }
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                                        withAnimation(.easeInOut) {
                                            showX.toggle()
                                        }
                                    }
                                }
                            }
                            Spacer()
                        }
                    }
                    
                    Spacer(minLength: 30)
                    
                    // Back Button
                    HStack {
                        withAnimation(.easeInOut) {
                            Button(action: {router.path.removeLast()}) {
                                Image(systemName: "arrowshape.turn.up.backward.circle.fill")
                                    .font(.system(size: 60))
                            }
                            .accessibilityLabel("Back")
                        }
                        Spacer()
                    }
                    .padding(.bottom)
                }
            }
            .padding(.horizontal, 50)
            .background(Color.background)
            .foregroundStyle(Color.text)
            .onAppear {
                showInstruction.toggle()
            }
            .overlay {
                if showInterpretation {
                    withAnimation(.easeInOut) {
                        InterpretationModal(showInterpretation: $showInterpretation/*, navigate: $navigate*/)
                            .environmentObject(viewModel)
                            .environmentObject(router)
                    }
                }
                if showInstruction {
                    withAnimation(.easeInOut) {
                        InstructionModal(showModal: $showInstruction)
                    }
                }
                if showX {
                    withAnimation(.easeInOut) {
                        WrongResponseModal()
                    }
                }
            }
            .toolbar(.hidden, for: .navigationBar)
    }
}

struct InstructionModal: View {
    @Binding var showModal: Bool
    
    var body: some View {
        Color.black.opacity(0.5)
            .edgesIgnoringSafeArea(.all)
            .overlay(
                VStack {
                    Text("Click on the material corresponding to the part of the statue, as described in the Bible verse.")
                        .padding()
                        .multilineTextAlignment(.center)
                    
                    Divider()
                        .background(Color.gray)
                    
                    Button("OK") {
                        showModal = false
                    }
                    .padding()
                    .fontWeight(.semibold)
                    .cornerRadius(10)
                }
                    .background(Color.background)
                    .cornerRadius(15)
                    .shadow(radius: 20)
                    .padding(100)
                    .foregroundStyle(Color.text)
                    .font(.system(size: 25, weight: .regular))
            )
    }
}

struct WrongResponseModal: View {
    var body: some View {
        Color.black.opacity(0.3)
            .edgesIgnoringSafeArea(.all)
            .overlay(
                VStack {
                    Text("X")
                        .opacity(0.7)
                        .font(.system(size: 200, weight: .bold))
                        .foregroundStyle(Color.red)
                        .accessibilityLabel("The answer is incorrect. Please try again.")
                        .accessibilityAddTraits(.isHeader) // importante
                }
            )
    }
}

struct InterpretationModal: View {
    @EnvironmentObject var router: Router
    @EnvironmentObject var viewModel: DreamViewModel
    @Binding var showInterpretation: Bool
    @State private var currentInfo = 1
    
    var body: some View {
        Color.black.opacity(0.5)
            .edgesIgnoringSafeArea(.all)
            .overlay(
                VStack {
                    Text("Interpretation")
                        .font(.system(size: 34, weight: .semibold))
                        .padding(.top)
                    
                    Divider()
                        .background(Color.gray)
                    
                    HStack {
                        Button(
                            action: {
                                if currentInfo == 2 {
                                    currentInfo = 1
                                }
                            },
                            label: {
                                Image(systemName: "arrowshape.backward.circle.fill")
                                    .accessibilityLabel("Back")
                                    .font(.largeTitle)
                            })
                        .disabled(currentInfo == 1)
                        .opacity(currentInfo == 1 ? 0.3 : 1)
                        .padding(.leading)
                        
                        VStack {
                            Image(systemName: currentInfo == 1 ? "book.fill": "mappin.and.ellipse")
                                .font(.system(size: 34))
                                .padding(.top)
                                .accessibilityHidden(true)
                            
                            Text(currentInfo == 1 ? viewModel.currentPart.interpretationText : viewModel.currentPart.historicalContext)
                                .padding()
                                .multilineTextAlignment(.center)
                        }
                        // Back Button
                        Button(
                            action: {
                                if currentInfo == 1 {
                                    currentInfo = 2
                                }
                            },
                            label: {
                                Image(systemName: "arrowshape.forward.circle.fill")
                                    .font(.largeTitle)
                                    .accessibilityLabel("Next")
                            })
                        .disabled(currentInfo == 2)
                        .opacity(currentInfo == 2 ? 0.3 : 1)
                        .padding(.trailing)
                    }
                    .padding(.vertical)
                    
                    if currentInfo == 2 {
                        Divider()
                            .background(Color.gray)

                        HStack {
                            Button("Close") {
                                if viewModel.isPartCompleted {
                                    viewModel.currentPartIndex = 0
                                    viewModel.isPartCompleted = false
                                    router.goToFinalView()
                                } else {
                                    viewModel.advanceToNextPart()
                                }
                                showInterpretation = false
                                viewModel.isResponseCorrect.toggle()
                                viewModel.response.removeAll()
                            }
                            .padding()
                            .fontWeight(.semibold)
                            .foregroundStyle(Color.text)
                            .cornerRadius(10)
                        }
                    }
                }
                .background(Color.background)
                .cornerRadius(15)
                .shadow(radius: 20)
                .padding(.horizontal, 100)
                .foregroundStyle(Color.text)
                .font(.system(size: 25, weight: .regular))
            )
    }
}

#Preview {
    DreamView()
        .environmentObject(Router())
}

#Preview {
    @State var showInterpretation = true

    InterpretationModal(showInterpretation: $showInterpretation)
        .environmentObject(DreamViewModel())
}

#Preview {
    WrongResponseModal()
}
