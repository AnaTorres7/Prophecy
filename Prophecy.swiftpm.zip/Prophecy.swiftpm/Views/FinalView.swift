//
//  FinalView.swift
//  Prophecy
//
//  Created by Ana Flávia Torres do Carmo on 12/12/24.
//

import SwiftUI

struct FinalView: View {
    @EnvironmentObject var router: Router
    @State private var screenWidth = UIScreen.main.bounds.width
    @State private var screenHeight = UIScreen.main.bounds.height
    
    let finalImages = ["final1", "final2", "final3"]
    @State var finalImage = "final1"
    
    let finalTexts = [
        "Dream:... a rock was cut from a mountain, but not by human hands ... Dan 2:34 (NLT) \nInterpretation: During the reigns of those kings, the God of heaven will set up a kingdom... Dan 2:44 (NLT)",
        "Dream:... It struck the feet of iron and clay, smashing them to bits. The whole statue was crushed into small pieces of iron, clay, bronze, silver, and gold. Then the wind blew them away without a trace, like chaff on a threshing floor... Dan 2:34-35 (NLT) \nInterpretation: ...It will crush all these kingdoms into nothingness, ... Dan 2:44 (NLT)",
        "Dream:... But the rock that knocked the statue down became a great mountain that covered the whole earth. Dan 2:35 (NLT) \nInterpretation: ...and it will stand forever...The great God has shown the king what will happen in the future. The dream is true, and its interpretation is trustworthy. Dan 2:44-45 (NLT)"
    ]
    @State var textIndex = 0
    
    private func getimageLable(finalImage: String) -> String {
        switch finalImage {
        case finalImages.first: return "Image of the Rock cut from the Mountain"
        case finalImages.last: return "Image of the Great God Kingdom"
        default: return "Image of the Rock destroying the statue."
        }
    }
    
    var body: some View {
        ZStack {
            if finalImage == finalImages.last {
                VStack {
                    Spacer()
                    Image(decorative: finalImage)
                        .resizable()
                        .frame(width: screenWidth)
                        .transition(.opacity)
                        .accessibilityLabel(getimageLable(finalImage: finalImage))
                }
                .ignoresSafeArea()
            }
            
            
            VStack {
                VStack(alignment: .leading) {
                    Text("Final")
                        .font(.system(size: 41, weight: .medium))
                    //                    Text("Dn 2: 44-45 (NLT)")
                    //                        .font(.system(size: 28, weight: .medium))
                        .padding(.bottom)
                    Text(finalTexts[textIndex])
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.vertical, 20)
                
                Spacer()
                
                if finalImage != finalImages.last {
                    Image(decorative: finalImage)
                        .resizable()
                        .scaledToFit()
                        .transition(.opacity)
                        .padding(.bottom, screenHeight/10)
                        .accessibilityLabel(getimageLable(finalImage: finalImage))
                }
                
                // Next Button
                HStack {
                    withAnimation(.easeInOut) {
                        Button(action: {
                            if textIndex == 0 {
                                router.path.removeLast()
                            } else {
                                textIndex -= 1
                                finalImage = finalImages[textIndex]
                            }
                        }) {
                            Image(systemName: "arrowshape.turn.up.backward.circle.fill")
                                .foregroundStyle(textIndex == finalImages.count-1 ? .white : Color.text)
                                .font(.system(size: 60))
                        }
                        .accessibilityLabel("Back")
                    }
                    Spacer()
                    if finalImage == finalImages.last {
                        withAnimation(.easeInOut) {
                            Button(action: {
                                router.restart()
                            }) {
                                Image(systemName: "repeat.circle.fill")
                                    .font(.system(size: 60))
                            }
                            .foregroundStyle(.white)
                            .accessibilityLabel("Back to Cover")
                        }
                    } else {
                        withAnimation(.easeInOut) {
                            Button(action: {
                                textIndex += 1
                                finalImage = finalImages[textIndex]
                            }) {
                                Image(systemName: "arrowshape.turn.up.right.circle.fill")
                                    .font(.system(size: 60))
                            }
                            .accessibilityLabel("Next")
                        }
                    }
                }
                .padding(.bottom)
            }
            .padding(.horizontal,50)
        }
        .background(Color.background)
        .toolbar(.hidden, for: .navigationBar)
        .foregroundStyle(Color.text)
        .font(.system(size: 25, weight: .medium))
//        .onAppear {
//            for index in 1..<finalImages.count {
//                DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 3) {
//                    withAnimation(.easeInOut) {
//                        finalImage = finalImages[index]
//                        textIndex = index
//                    }
//                }
//            }
//        }
    }
}

#Preview {
    FinalView()
        .environmentObject(Router())
}
