//
//  DreamViewModel.swift
//  Prophecy
//
//  Created by Ana Flávia Torres do Carmo on 08/12/24.
//


import Foundation

class DreamViewModel: ObservableObject {
    @Published var currentPartIndex: Int = 0
    @Published var isPartCompleted: Bool = false
    @Published var isResponseCorrect : Bool = false
    @Published var response: [String] = []

    let parts: [StatuePart] = [
        StatuePart(
            name: "Head",
            materialImage: ["Gold"],
            statueImage: "Head_P",
            referenceText: "Dan 2:32 (NLT)",
            verseText: "The head of the statue was made of pure gold, ...",
            interpretationText: "“Your Majesty, you are the greatest of kings. The God of heaven has given you sovereignty, power, strength, and honor. He has made you the ruler over all the inhabited world and has put even the wild animals and birds under your control. You are the head of gold.” Dan 2:37-38 (NLT)",
            historicalContext: "Babylon ruled the world from 605 BC to 539 BC. Gold was the metal symbolizing the power and wealth of the Babylonian Empire. Biblical references describe this city as “the golden city” (Isa 14:4, KJV) and “a golden cup in the Lord’s hand” (Jer 51:7; Rev 18:16). Herodotus, an ancient historian, wrote that the city was richly adorned with gold."
        ),
        StatuePart(
            name: "Chest",
            materialImage: ["Silver"],
            statueImage: "Chest_P",
            referenceText: "Dan 2:32 (NLT)",
            verseText: "Its chest and arms were silver, ...",
            interpretationText: "“After your kingdom, there will be another, not as powerful as yours; …” Dan 2:39 (NLT)",
            historicalContext: "The Medo-Persian Empire ruled the world from 539 BC to 331 BC. Silver, being less valuable than gold, reflects the fact that the Medo-Persian Empire did not reach the same splendor as the Babylonian Empire. Additionally, it was a fitting symbol for the Persians, as silver was widely used in their tribute system."
        ),
        StatuePart(
            name: "Belly",
            materialImage: ["Bronze"],
            statueImage: "Belly_P",
            referenceText: "Dan 2:32 (NLT)",
            verseText: "Its belly and thighs were bronze,",
            interpretationText: "“… and after that, there will be another kingdom, a kingdom of bronze, that will rule over the entire world.” Dan 2:39 (NLT)",
            historicalContext: "Greece ruled the world from 331 BC to 168 BC. Ezekiel 27:13 mentions the Greeks trading items made of bronze. This metal was also characteristic of their soldiers, who were known for wearing bronze armor, including helmets, shields, and battle axes."
        ),
        StatuePart(
            name: "Legs",
            materialImage: ["Iron"],
            statueImage: "Legs_P",
            referenceText: "Dan 2:33 (NLT)",
            verseText: "Its legs were made of iron, ...",
            interpretationText: "“Then there will be a fourth kingdom, strong as iron, which breaks and crushes everything. And just as iron breaks everything, this kingdom will destroy all the other kingdoms of the world.” Dan 2:40 (NLT)",
            historicalContext: "Rome ruled the world from 168 BC to AD 476. Daniel explained that iron symbolized the crushing strength of the Roman Empire, which lasted longer than all the previous kingdoms. This metal was an ideal representation of the empire’s power."
        ),
        StatuePart(
            name: "Feet",
            materialImage: ["Iron", "Clay"],
            statueImage: "Feet_P",
            referenceText: "Dan 2:33 (NLT)",
            verseText: "And its feet were a combination of iron and baked clay.",
            interpretationText: "“In the statue you saw, the feet and toes were made of partly iron and partly clay. This means that this kingdom will be divided, but will have some of the strength of iron; for, as you saw, the iron was mixed with clay. The toes were partly iron and partly clay; this means that the kingdom will be strong on one hand, but weak on the other. You saw, O king, that the iron was mixed with clay, and this means that the kings will try to unite their kingdoms through marriage. But since iron and clay do not mix, these kingdoms will not remain united.” Dan 2:41-43 (NLT)",
            historicalContext: "Its dominion spans from AD 476 until the Second Coming of Christ. After the Roman Empire, there was a division into ten kingdoms, represented by the toes of the statue. The iron and clay show that some of these kingdoms would be strong, like the Franks and the Visigoths, while others would be weak. Despite several attempts to unify Europe, the division persists, fulfilling the prophecy that this situation will continue until God establishes His eternal kingdom."
        )
    ]
    
    func getPartName() -> String {
        switch currentPart.name {
            case "Head": return "Head"
            case "Chest": return "Chest and Arms"
            case "Belly": return "Belly and Thighs"
            case "Legs": return "Legs"
            default:
                return "Feet"
        }
    }

    func advanceToNextPart() {
        if currentPartIndex < parts.count - 1 {
            currentPartIndex += 1
            isPartCompleted = currentPartIndex == parts.count - 1 ? true : false
        }
    }

    var currentPart: StatuePart {
        parts[currentPartIndex]
    }
}
