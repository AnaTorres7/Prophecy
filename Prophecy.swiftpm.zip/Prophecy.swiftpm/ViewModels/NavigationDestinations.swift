//
//  NavigationDestinations.swift
//  Prophecy
//
//  Created by Ana Flávia Torres do Carmo on 12/12/24.
//

import SwiftUI

// Enum para os destinos de navegação
enum NavigationDestinations: Hashable {
    case CoverView
    case InfoView
    case IntroView
    case DreamView
    case FinalView
    
}

class Router: ObservableObject {
    @Published var path = NavigationPath()

    func clear() {
        path = .init()
    }

    func goToCoverView() {
        path.append(NavigationDestinations.CoverView)
    }
    func goToInfoView() {
        path.append(NavigationDestinations.InfoView)
    }

    func goToIntroView() {
        path.append(NavigationDestinations.IntroView)
    }

    func goToDreamView() {
        path.append(NavigationDestinations.DreamView)
    }

    func goToFinalView() {
        path.append(NavigationDestinations.FinalView)
    }
    
    func restart() {
        clear()
        goToCoverView()
    }
}

// Função que retorna a view para cada destino
@ViewBuilder
func getView(_ destination: NavigationDestinations) -> some View {
    switch destination {
    case .CoverView:
        CoverView()
    case .InfoView:
        InfoView()
    case .IntroView:
        IntroView()
    case .DreamView:
        DreamView()
    case .FinalView:
        FinalView()
    }
}
