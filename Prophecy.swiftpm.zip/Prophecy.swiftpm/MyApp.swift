import SwiftUI

@main
struct MyApp: App {
    @ObservedObject var router = Router()
    
    var body: some Scene {
        WindowGroup {
            CoverView()
                .environmentObject(router)
        }
    }
}
