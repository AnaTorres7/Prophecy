//
//  StatuePart.swift
//  Prophecy
//
//  Created by Ana Flávia Torres do Carmo on 08/12/24.
//


import Foundation

struct StatuePart: Identifiable {
    let id = UUID()
    let name: String
    let materialImage: Array<String>
    let statueImage: String
    let referenceText: String
    let verseText: String
    let interpretationText: String
    let historicalContext: String

}

enum Materials: CaseIterable {
    case Gold, Silver, Bronze, Iron, Clay
}
