import SwiftUI

extension Color {
    static let background = Color(uiColor: UIColor { traitCollection in
        traitCollection.userInterfaceStyle == .dark
        ? UIColor(red: 0.718, green: 0.522, blue: 0.333, alpha: 1.0)
        : UIColor(red: 1.0, green: 0.9647, blue: 0.9255, alpha: 1.0)
    })
    
    static let text = Color(uiColor: UIColor { traitCollection in
        traitCollection.userInterfaceStyle == .dark
        ? UIColor(red: 1.0, green: 0.9647, blue: 0.9255, alpha: 1.0)
        : UIColor(red: 0.718, green: 0.522, blue: 0.333, alpha: 1.0)
    })
}
